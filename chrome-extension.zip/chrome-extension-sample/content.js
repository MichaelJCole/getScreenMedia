sessionStorage.getScreenMediaJSExtensionId = chrome.runtime.id;
